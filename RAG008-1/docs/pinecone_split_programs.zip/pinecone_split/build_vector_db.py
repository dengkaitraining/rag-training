"""建立 Pinecone Integrated Embedding Index，並寫入 Data Chunks。"""

import os
import time
from typing import Any

from dotenv import load_dotenv
from pinecone import Pinecone

INDEX_NAME = "course-rag-demo"
NAMESPACE = "ai-course"
EMBEDDING_MODEL = "llama-text-embed-v2"
TEXT_FIELD = "chunk_text"

RECORDS: list[dict[str, Any]] = [
    {
        "_id": "doc-001",
        "chunk_text": "RAG 是結合資訊檢索與大型語言模型的生成式人工智慧技術。",
        "category": "RAG",
        "source": "AI課程第一章",
    },
    {
        "_id": "doc-002",
        "chunk_text": "向量資料庫可根據語意相似度搜尋與問題最相關的文件。",
        "category": "VectorDB",
        "source": "AI課程第二章",
    },
    {
        "_id": "doc-003",
        "chunk_text": "AI Agent 可以使用工具、存取資料，並根據目標執行多個步驟。",
        "category": "Agent",
        "source": "AI課程第三章",
    },
    {
        "_id": "doc-004",
        "chunk_text": "Flask 是一個輕量級的 Python Web Application Framework。",
        "category": "Python",
        "source": "Python課程",
    },
    {
        "_id": "doc-005",
        "chunk_text": "Pinecone 是雲端託管的向量資料庫，可應用於語意搜尋與 RAG。",
        "category": "VectorDB",
        "source": "AI課程第二章",
    },
    {
        "_id": "doc-006",
        "chunk_text": "Netflix is a time killer.",
        "category": "Hobby",
        "source": "DOC-123-tyyty",
    },
    {
        "_id": "doc-007",
        "chunk_text": (
            "A blockchain is a distributed ledger with growing lists of records "
            "called blocks that are securely linked using cryptographic hashes. "
            "Each block normally contains the previous block's hash, a timestamp, "
            "and transaction data. Because blocks are linked, changing an earlier "
            "record generally requires changing subsequent blocks and obtaining "
            "network consensus."
        ),
        "category": "Blockchain",
        "source": "DOC-123-tyyty",
    },
    {
        "_id": "doc-008",
        "chunk_text": "MAGA 是 Make America Great Again 的縮寫，中文常譯為讓美國再次偉大。",
        "category": "Politics",
        "source": "course-example",
    },
]


def get_client() -> Pinecone:
    """讀取 API Key 並建立 Pinecone Client。"""
    load_dotenv()
    api_key = os.getenv("PINECONE_API_KEY")

    if not api_key:
        raise RuntimeError("找不到 PINECONE_API_KEY，請確認 .env 設定。")

    return Pinecone(api_key=api_key)


def wait_until_index_ready(pc: Pinecone, index_name: str, timeout: int = 180) -> None:
    """等待新建立的 Index 可接受資料。"""
    deadline = time.time() + timeout

    while time.time() < deadline:
        description = pc.describe_index(index_name)
        status = getattr(description, "status", None)

        if isinstance(status, dict):
            ready = bool(status.get("ready"))
        else:
            ready = bool(getattr(status, "ready", False))

        if ready:
            return

        time.sleep(2)

    raise TimeoutError(f"Index '{index_name}' 在 {timeout} 秒內仍未就緒。")


def wait_until_records_visible(index: Any, namespace: str, expected_count: int, timeout: int = 60) -> None:
    """等待 upsert 的資料出現在 Index 統計中。"""
    deadline = time.time() + timeout

    while time.time() < deadline:
        stats = index.describe_index_stats()
        namespaces = getattr(stats, "namespaces", {}) or {}
        namespace_stats = namespaces.get(namespace)

        if namespace_stats is not None:
            count = getattr(namespace_stats, "vector_count", None)
            if count is None and isinstance(namespace_stats, dict):
                count = namespace_stats.get("vector_count", 0)
            if int(count or 0) >= expected_count:
                return

        time.sleep(2)

    print("警告：資料已送出，但統計資訊尚未完全更新；稍後仍可執行檢索。")


def main() -> None:
    pc = get_client()

    if not pc.has_index(INDEX_NAME):
        print(f"建立 Index：{INDEX_NAME}")
        pc.create_index_for_model(
            name=INDEX_NAME,
            cloud="aws",
            region="us-east-1",
            embed={
                "model": EMBEDDING_MODEL,
                "field_map": {"text": TEXT_FIELD},
            },
        )
        wait_until_index_ready(pc, INDEX_NAME)
    else:
        print(f"Index 已存在：{INDEX_NAME}")

    description = pc.describe_index(INDEX_NAME)
    host = getattr(description, "host", None)
    if not host and isinstance(description, dict):
        host = description.get("host")

    index = pc.Index(host=host) if host else pc.Index(INDEX_NAME)

    print(f"寫入 {len(RECORDS)} 筆 Data Chunks 至 namespace：{NAMESPACE}")
    index.upsert_records(namespace=NAMESPACE, records=RECORDS)
    wait_until_records_visible(index, NAMESPACE, len(RECORDS))

    print("\n向量資料庫建立／更新完成。")
    print(index.describe_index_stats())


if __name__ == "__main__":
    main()
