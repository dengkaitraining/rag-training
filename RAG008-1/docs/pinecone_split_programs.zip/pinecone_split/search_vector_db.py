"""連接既有 Pinecone Index，執行文字語意檢索。"""

import os
from typing import Any

from dotenv import load_dotenv
from pinecone import Pinecone

INDEX_NAME = "course-rag-demo"
NAMESPACE = "ai-course"
TOP_K = 3
RETURN_FIELDS = ["chunk_text", "category", "source"]


def get_client() -> Pinecone:
    """讀取 API Key 並建立 Pinecone Client。"""
    load_dotenv()
    api_key = os.getenv("PINECONE_API_KEY")

    if not api_key:
        raise RuntimeError("找不到 PINECONE_API_KEY，請確認 .env 設定。")

    return Pinecone(api_key=api_key)


def get_value(obj: Any, *keys: str, default: Any = None) -> Any:
    """同時相容 dict 與 Pinecone SDK 回傳物件。"""
    for key in keys:
        if isinstance(obj, dict) and key in obj:
            return obj[key]
        if hasattr(obj, key):
            return getattr(obj, key)
    return default


def main() -> None:
    pc = get_client()

    if not pc.has_index(INDEX_NAME):
        raise RuntimeError(
            f"找不到 Index '{INDEX_NAME}'。請先執行 build_vector_db.py。"
        )

    description = pc.describe_index(INDEX_NAME)
    host = get_value(description, "host")
    index = pc.Index(host=host) if host else pc.Index(INDEX_NAME)

    question = input("請輸入檢索問題：").strip()
    if not question:
        raise ValueError("檢索問題不可為空白。")

    results = index.search(
        namespace=NAMESPACE,
        query={
            "top_k": TOP_K,
            "inputs": {"text": question},
        },
        fields=RETURN_FIELDS,
    )

    result_block = get_value(results, "result", default={})
    hits = get_value(result_block, "hits", default=[]) or []

    print(f"\n問題：{question}")
    print("=" * 70)

    if not hits:
        print("沒有找到相關資料。")
        return

    for rank, hit in enumerate(hits, start=1):
        record_id = get_value(hit, "_id", "id", default="N/A")
        score = get_value(hit, "_score", "score", default=0.0)
        fields = get_value(hit, "fields", default={}) or {}

        print(f"排名：{rank}")
        print(f"ID：{record_id}")
        print(f"分數：{float(score):.6f}")
        print(f"內容：{get_value(fields, 'chunk_text', default='')}")
        print(f"分類：{get_value(fields, 'category', default='')}")
        print(f"來源：{get_value(fields, 'source', default='')}")
        print("-" * 70)


if __name__ == "__main__":
    main()
