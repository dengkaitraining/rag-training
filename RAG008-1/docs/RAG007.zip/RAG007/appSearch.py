"""使用 Flask 建立 Pinecone 語意檢索 Web Application。"""

import os
from typing import Any

from dotenv import load_dotenv
from flask import Flask, redirect, render_template, request, url_for
from pinecone import Pinecone


# --------------------------------------------------
# Pinecone 設定
# --------------------------------------------------

INDEX_NAME = "course-rag-demo"
NAMESPACE = "ai-course"
TOP_K = 3

RETURN_FIELDS = [
    "chunk_text",
    "category",
    "source",
]


# --------------------------------------------------
# 建立 Flask Application
# --------------------------------------------------

app = Flask(__name__)


def get_value(
    obj: Any,
    *keys: str,
    default: Any = None,
) -> Any:
    """
    同時相容 dict 與 Pinecone SDK 回傳物件。

    例如：
    hit["_id"]
    hit.id
    """

    for key in keys:
        if isinstance(obj, dict) and key in obj:
            return obj[key]

        if hasattr(obj, key):
            return getattr(obj, key)

    return default


def create_pinecone_index():
    """
    建立 Pinecone Client，並連接既有 Index。

    注意：
    本程式不負責建立向量資料庫，
    必須先執行 build_vector_db.py。
    """

    load_dotenv()

    api_key = os.getenv("PINECONE_API_KEY")

    if not api_key:
        raise RuntimeError(
            "找不到 PINECONE_API_KEY，請確認 .env 設定。"
        )

    pc = Pinecone(api_key=api_key)

    if not pc.has_index(INDEX_NAME):
        raise RuntimeError(
            f"找不到 Index '{INDEX_NAME}'，"
            "請先執行 build_vector_db.py 建立向量資料庫。"
        )

    description = pc.describe_index(INDEX_NAME)

    host = get_value(
        description,
        "host",
        default=None,
    )

    if host:
        return pc.Index(host=host)

    return pc.Index(INDEX_NAME)


# --------------------------------------------------
# 程式啟動時連接 Pinecone
# --------------------------------------------------

try:
    pinecone_index = create_pinecone_index()
    startup_error = None

except Exception as error:
    pinecone_index = None
    startup_error = str(error)


# --------------------------------------------------
# 首頁
# --------------------------------------------------

@app.route("/", methods=["GET"])
def home():
    """
    顯示靜態 user_prompt 頁面。

    static/index.html 不經過 Jinja2 處理。
    """

    return app.send_static_file("index.html")


# --------------------------------------------------
# Pinecone 檢索
# --------------------------------------------------

@app.route("/search", methods=["POST"])
def search():
    """
    接收表單中的 user_prompt，
    呼叫 Pinecone 執行語意檢索，
    再使用 result.html 顯示動態結果。
    """

    if startup_error:
        return render_template(
            "result.html",
            question="",
            results=[],
            error_message=startup_error,
        ), 500

    question = request.form.get(
        "user_prompt",
        "",
    ).strip()

    if not question:
        return render_template(
            "result.html",
            question="",
            results=[],
            error_message="請輸入檢索問題。",
        ), 400

    try:
        search_results = pinecone_index.search(
            namespace=NAMESPACE,
            query={
                "top_k": TOP_K,
                "inputs": {
                    "text": question
                },
            },
            fields=RETURN_FIELDS,
        )

        result_block = get_value(
            search_results,
            "result",
            default={},
        )

        hits = get_value(
            result_block,
            "hits",
            default=[],
        ) or []

        formatted_results = []

        for rank, hit in enumerate(hits, start=1):
            record_id = get_value(
                hit,
                "_id",
                "id",
                default="N/A",
            )

            score = get_value(
                hit,
                "_score",
                "score",
                default=0.0,
            )

            fields = get_value(
                hit,
                "fields",
                default={},
            ) or {}

            formatted_results.append(
                {
                    "rank": rank,
                    "record_id": record_id,
                    "score": float(score),
                    "chunk_text": get_value(
                        fields,
                        "chunk_text",
                        default="",
                    ),
                    "category": get_value(
                        fields,
                        "category",
                        default="",
                    ),
                    "source": get_value(
                        fields,
                        "source",
                        default="",
                    ),
                }
            )

        return render_template(
            "result.html",
            question=question,
            results=formatted_results,
            error_message=None,
        )

    except Exception as error:
        return render_template(
            "result.html",
            question=question,
            results=[],
            error_message=f"Pinecone 檢索失敗：{error}",
        ), 500


# --------------------------------------------------
# 回首頁
# --------------------------------------------------

@app.route("/back", methods=["GET"])
def back():
    return redirect(url_for("home"))


# --------------------------------------------------
# 啟動 Flask
# --------------------------------------------------

if __name__ == "__main__":
    app.run(
        host="127.0.0.1",
        port=5000,
        debug=True,
    )