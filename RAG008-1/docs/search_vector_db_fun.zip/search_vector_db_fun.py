"""連接既有 Pinecone Index，執行文字語意檢索。"""

import os
from typing import Any

from dotenv import load_dotenv
from pinecone import Pinecone


INDEX_NAME = "course-rag-demo"
NAMESPACE = "ai-course"
TOP_K = 3

RETURN_FIELDS = [
    "chunk_text",
    "category",
    "source",
]


def get_client() -> Pinecone:
    """讀取 API Key 並建立 Pinecone Client。"""

    load_dotenv()

    api_key = os.getenv("PINECONE_API_KEY")

    if not api_key:
        raise RuntimeError(
            "找不到 PINECONE_API_KEY，請確認 .env 設定。"
        )

    return Pinecone(api_key=api_key)


def get_value(
    obj: Any,
    *keys: str,
    default: Any = None,
) -> Any:
    """同時相容 dict 與 Pinecone SDK 回傳物件。"""

    for key in keys:
        if isinstance(obj, dict) and key in obj:
            return obj[key]

        if hasattr(obj, key):
            return getattr(obj, key)

    return default


def search_Vec_DB(question: str) -> str:
    """
    接收使用者問題，檢索 Pinecone 向量資料庫。

    Args:
        question:
            使用者輸入的檢索問題。

    Returns:
        將所有檢索結果串接後形成的字串。
    """

    question = question.strip()

    if not question:
        raise ValueError("檢索問題不可為空白。")

    # 建立 Pinecone Client
    pc = get_client()

    # 確認 Index 是否存在
    if not pc.has_index(INDEX_NAME):
        raise RuntimeError(
            f"找不到 Index '{INDEX_NAME}'。"
            "請先執行 build_vector_db.py。"
        )

    # 取得 Index 的連線資訊
    description = pc.describe_index(INDEX_NAME)

    host = get_value(
        description,
        "host",
        default=None,
    )

    # 連接 Pinecone Index
    if host:
        index = pc.Index(host=host)
    else:
        index = pc.Index(INDEX_NAME)

    # 執行語意檢索
    results = index.search(
        namespace=NAMESPACE,
        query={
            "top_k": TOP_K,
            "inputs": {
                "text": question,
            },
        },
        fields=RETURN_FIELDS,
    )

    # 取得檢索結果
    result_block = get_value(
        results,
        "result",
        default={},
    )

    hits = get_value(
        result_block,
        "hits",
        default=[],
    ) or []

    # 建立回傳字串
    output_string = ""

    output_string += f"問題：{question}\n"
    output_string += "=" * 70
    output_string += "\n"

    # 沒有找到資料
    if not hits:
        output_string += "沒有找到相關資料。\n"
        return output_string

    # 將每一筆檢索結果串接到 output_string
    for rank, hit in enumerate(hits, start=1):

        record_id = get_value(
            hit,
            "_id",
            "id",
            default="N/A",
        )

        score = get_value(
            hit,
            "_score",
            "score",
            default=0.0,
        )

        fields = get_value(
            hit,
            "fields",
            default={},
        ) or {}

        chunk_text = get_value(
            fields,
            "chunk_text",
            default="",
        )

        category = get_value(
            fields,
            "category",
            default="",
        )

        source = get_value(
            fields,
            "source",
            default="",
        )

        output_string += f"排名：{rank}\n"
        output_string += f"ID：{record_id}\n"
        output_string += f"分數：{float(score):.6f}\n"
        output_string += f"內容：{chunk_text}\n"
        output_string += f"分類：{category}\n"
        output_string += f"來源：{source}\n"
        output_string += "-" * 70
        output_string += "\n"

    return output_string


def main() -> None:
    """主程式：輸入問題並呼叫 search_Vec_DB()。"""

    question = input("請輸入檢索問題：")

    try:
        # 呼叫向量資料庫檢索函式
        search_result = search_Vec_DB(question)

        # 顯示函式回傳的串接字串
        print()
        print(search_result)

    except Exception as error:
        print(f"執行失敗：{error}")


if __name__ == "__main__":
    main()