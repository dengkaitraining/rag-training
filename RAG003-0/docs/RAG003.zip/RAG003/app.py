from flask import Flask, request, render_template
import os
import requests

app = Flask(__name__)


@app.route("/")
def index():
    # 使用靜態網頁 index.html
    # 注意：這裡使用 app.send_static_file()
    return app.send_static_file("index.html")


@app.route("/process", methods=["POST"])
def process():
    # 從 <form> 接收 user_prompt 欄位
    user_prompt = request.form.get("user_prompt")
    user_prompt ="<user_prompt>" + user_prompt + "</user_prompt>"
	# 加上  Augmented 的 context 與 Specifier
    context="""<context>
	  AI Agent 時代 ─ 從工具走向自主協作，企業自動化正在被重新定義！
      當大型語言模型（LLM）結合 Workflow、API 與企業系統，自動化不再只是流程優化，而是邁向具備情境理解與跨系統協作能力的 Agentic Automation 新階段。
	  IOT是Internet of Things，感測環境，蒐集數據，進行控制。
	  </context>
	"""
    specifier="<specifier>從context找出user_prompt的答案，如果找不到就說不知道</specifier>"	
    user_prompt= user_prompt + context + specifier
    # 向 LLM API發出 Request，得到回應，送到 ouput.html呈現
    API_KEY = os.getenv("GEMINI_API_KEY")
    if not API_KEY:
      raise ValueError("找不到 GEMINI_API_KEY，請先設定環境變數")
    url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent"

    headers = {
      "Content-Type": "application/json",
      "X-goog-api-key": API_KEY
    }

    data = {
      "contents": [
          {
            "parts": [
                {
                    "text": user_prompt
                }
            ]
          }
       ]
    }

    response = requests.post(url, headers=headers, json=data)

    print(response.status_code)
    #print(response.json())
    result=response.json()
    # 將收到的 user_prompt 傳給動態網頁 output.html
    return render_template("output.html", user_prompt=user_prompt,result=result)


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0")