from flask import Flask, request, render_template
import pymysql

app = Flask(__name__)

# MySQL 連線資訊
db = pymysql.connect(
    host="localhost",
    user="root",
    password="A123456789",
    database="chunk",
    charset="utf8mb4",
    cursorclass=pymysql.cursors.DictCursor
)

#---------------------------------------------------
# 首頁 (靜態網頁)
#---------------------------------------------------
@app.route("/")
def home():
    return app.send_static_file("index.html")


#---------------------------------------------------
# 查詢
#---------------------------------------------------
@app.route("/search", methods=["POST"])
def search():

    fields = request.form.getlist("field")
    keyword = request.form.get("value", "").strip()

    if len(fields) == 0:
        return render_template(
            "result.html",
            rows=[],
            message="請至少選擇一個欄位。"
        )

    if keyword == "":
        return render_template(
            "result.html",
            rows=[],
            message="請輸入查詢值。"
        )

    where_list = []
    params = []

    for f in fields:
        if f in ["ID", "keyword", "content"]:
            where_list.append(f"{f} LIKE %s")
            params.append("%" + keyword + "%")

    sql = "SELECT * FROM imychunk"

    if where_list:
        sql += " WHERE " + " OR ".join(where_list)

    cursor = db.cursor()
    cursor.execute(sql, params)

    rows = cursor.fetchall()

    if len(rows) == 0:
        return render_template(
            "result.html",
            rows=[],
            message="查無資料"
        )

    return render_template(
        "result.html",
        rows=rows,
        message=""
    )


if __name__ == "__main__":
    app.run(debug=True)